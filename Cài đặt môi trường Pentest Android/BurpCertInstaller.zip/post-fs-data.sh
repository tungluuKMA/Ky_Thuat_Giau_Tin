#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

ui_print "Copying 9a5ba575.0 to /system/etc/security/cacerts/"
mkdir -p $MODDIR/system/etc/security/cacerts
rm $MODDIR/system/etc/security/cacerts/*
cp -f $MODDIR/9a5ba575.0 $MODDIR/system/etc/security/cacerts/
set_perm 0 0 0644 $MODDIR/system/etc/security/cacerts/9a5ba575.0


# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
